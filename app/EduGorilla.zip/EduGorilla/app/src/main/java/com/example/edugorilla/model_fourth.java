package com.example.edugorilla;

public class model_fourth {
    public String Title;

    public model_fourth(String title) {
        Title = title;
    }

    public model_fourth() {
    }

    public String getTitle() {
        return Title;
    }
}
